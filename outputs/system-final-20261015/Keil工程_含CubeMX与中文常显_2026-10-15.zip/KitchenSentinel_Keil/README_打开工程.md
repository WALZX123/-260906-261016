# 答辩工程入口（2026-10-15）

打开 firmware/stm32f103_hardware_test/Projects/MDK-ARM/atk_f103.uvprojx；换目录先 Rebuild All 再跳转定义。
CubeMX 打开 firmware/stm32f103_hardware_test/CubeMX/KitchenSentinel_F103.ioc。引脚与时序见相邻README。
源码、实际头文件依赖、原厂器件包、HEX/AXF/MAP和32份浏览文件均在包内。Keil/ARMCC需本机已有。
下载工具需要包根目录的 .venv（Python+pyOCD0.45.1），或使用完整项目现有环境；不运行下载也可直接查看代码和配置。
本包不含热点密码、令牌、数据库、私有配置或Flash备份。MCU无线配置页独立于公开HEX。
完整系统仍从原 kitchen-sentinel 项目运行 start.py 或 Start-WiFi.cmd；本包用于硬件代码答辩。
