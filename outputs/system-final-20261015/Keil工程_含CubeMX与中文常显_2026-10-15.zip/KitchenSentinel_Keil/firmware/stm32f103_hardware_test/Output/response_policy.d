..\..\output\response_policy.o: ..\..\Users\response_policy.c
..\..\output\response_policy.o: ..\..\Users\response_policy.h
..\..\output\response_policy.o: ..\..\Drivers\CompilerHeaders\stdint.h
