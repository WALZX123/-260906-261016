..\..\output\sensor_processing.o: ..\..\Users\sensor_processing.c
..\..\output\sensor_processing.o: ..\..\Users\sensor_processing.h
..\..\output\sensor_processing.o: ..\..\Drivers\CompilerHeaders\stdint.h
..\..\output\sensor_processing.o: ..\..\Drivers\CompilerHeaders\math.h
