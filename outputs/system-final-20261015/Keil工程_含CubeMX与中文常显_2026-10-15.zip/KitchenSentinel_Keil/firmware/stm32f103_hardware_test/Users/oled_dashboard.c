﻿/* 文件职责：OLED 六行连续运行看板。
 * 主要功能：12 像素中文、紧凑数字、完整传感器和四路输出、进度条、序号、运行时间、质量和刷新率。
 * 技术栈：C、单色显存、字模、变化页传输；模块联动：demo 同帧状态、ATK OLED 软件 I2C。
 * 编写/修改日期（日志对应）：2026-09-23、2026-10-13、2026-10-15。 */
#include "oled_dashboard.h"
#include "oled_glyphs.h"
#include "./BSP/ATK_OLED/atk_oled.h"
#include "stm32f1xx_hal.h"
#include <stdio.h>
#include <string.h>

/* 功能：只修改矩形显存，整帧完成后再更新变化页，显示期间不发送清屏或熄屏命令。
 * 输入：矩形与亮灭；联动：风险条及背景绘制。日期：2026-10-15。 */
static void rectangle(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t dot)
{
    uint16_t x, y;
    for (x=x1; x<=x2; x++) for (y=y1; y<=y2; y++) atk_oled_draw_point((uint8_t)x, (uint8_t)y, dot);
}

/* 功能：匹配项目 UTF-8 字符并绘制 12×12 字形，按像素边界截断，防止右侧越界。
 * 输入：坐标与中文串；输出：仅写显存。日期：2026-09-23、2026-10-15。 */
static void chinese(uint8_t x, uint8_t y, const char *text)
{
    while (*text && x<=116u) {
        uint32_t i,row,col;
        for (i=0; i<OLED_GLYPH_COUNT; i++) if (!memcmp(text,OLED_GLYPHS[i].utf8,3u)) {
            for (row=0; row<12u; row++) for (col=0; col<12u; col++)
                if (OLED_GLYPHS[i].rows[row]&(0x8000u>>col)) atk_oled_draw_point(x+col,y+row,1u);
            break;
        }
        text+=3; x+=12u;
    }
}

/* 功能：以固定基线绘制 5×8 ASCII，长序号也不换行清屏。
 * 输入：坐标及有界字符串；联动：测量值、序号、时间、质量和刷新率。日期：2026-10-15。 */
static void ascii(uint8_t x,uint8_t y,const char *text)
{
    while (*text && x<=123u) {
        uint8_t ch=(uint8_t)*text++,row,col;
        if (ch<32u||ch>126u) ch='?';
        for(row=0;row<8u;row++) for(col=0;col<5u;col++)
            if(OLED_ASCII[ch-32u][row]&(0x80u>>col)) atk_oled_draw_point(x+col,y+row,1u);
        x+=5u;
    }
}

/* 功能：保留燃气和烟雾的相对风险条，以 18 像素表示 0～100，不当作标定浓度。
 * 输入：条形起点与指标；输出：只写显存。日期：2026-09-23、2026-10-15。 */
static void bar(uint8_t x,uint8_t y,uint8_t value)
{
    uint8_t width=(uint8_t)(value*18u/100u);
    rectangle(x,y,x+18u,y,1u);
    if(width) rectangle(x,y+2u,x+width-1u,y+4u,1u);
}

/* 功能：六行保留此前全部信息；待机保留所有字段并显示缺测符号，禁止把旧值伪装为当前采样。
 * 输入：同帧指标、火焰、启用/基线/险情、四路输出、网络、演练、序号和运行时间。
 * 输出：变化页连续写入 OLED，屏幕始终点亮；刷新率由实际相邻绘制时间计算。
 * 模块联动：demo 和 atk_oled_refresh_changed；日期：2026-10-15。 */
void oled_dashboard(uint8_t gas,uint8_t smoke,int32_t temperature,uint8_t flame,uint8_t enabled,
                    uint8_t arming,uint8_t hazards,uint8_t valve_closed,uint8_t fan,
                    uint8_t buzzer,uint8_t relay,uint8_t wifi,uint8_t injection,
                    uint32_t sequence,uint32_t uptime_ms)
{
    static uint32_t previous_ms, smooth_rate;
    uint32_t now=HAL_GetTick(),elapsed=now-previous_ms,rate;
    char text[40];
    if(previous_ms && elapsed) {
        rate=10000u/elapsed;
        smooth_rate=smooth_rate?(smooth_rate*3u+rate)/4u:rate;
    }
    previous_ms=now;
    rectangle(0,0,127,63,0);
    chinese(0,0,"\xe7\x81\xb6\xe5\xae\x89" /* 灶安 */);
    chinese(30,0,!enabled?"\xe5\xbe\x85\xe6\x9c\xba" /* 待机 */:arming?"\xe6\xa3\x80\xe6\x9f\xa5" /* 检查 */:"\xe8\xbf\x90\xe8\xa1\x8c" /* 运行 */);
    chinese(60,0,!enabled?"\xe5\x81\x9c\xe9\x87\x87" /* 停采 */:hazards&2u?"\xe7\x81\xab\xe8\xad\xa6" /* 火警 */:hazards?"\xe6\xb0\x94\xe8\xad\xa6" /* 气警 */:temperature==(int32_t)0x80000000?"\xe9\x87\x87\xe6\x95\x85" /* 采故 */:"\xe6\xad\xa3\xe5\xb8\xb8" /* 正常 */);
    if(injection) chinese(88,0,"\xe6\xbc\x94" /* 演 */);
    ascii(112,2,wifi?"W+":"W-");
    chinese(0,12,"\xe7\x87\x83\xe6\xb0\x94" /* 燃气 */); chinese(64,12,"\xe7\x83\x9f\xe9\x9b\xbe" /* 烟雾 */);
    if(enabled) {
        snprintf(text,sizeof(text),"%3u",gas);ascii(26,14,text);
        snprintf(text,sizeof(text),"%3u",smoke);ascii(90,14,text);
        bar(44,15,gas);bar(108,15,smoke);
    } else {ascii(26,14," --");ascii(90,14," --");bar(44,15,0);bar(108,15,0);}
    chinese(0,24,"\xe6\xb8\xa9\xe5\xba\xa6" /* 温度 */);chinese(78,24,"\xe7\x81\xab\xe7\x84\xb0" /* 火焰 */);
    if(enabled && temperature!=(int32_t)0x80000000) {
        uint32_t magnitude=(uint32_t)(temperature<0?-temperature:temperature);
        snprintf(text,sizeof(text),"%s%lu.%luC",temperature<0?"-":"",
                 (unsigned long)(magnitude/100u),(unsigned long)(magnitude%100u/10u));
        ascii(26,26,text);
    } else ascii(26,26,"--.-C");
    ascii(106,26,enabled?(flame?"1":"0"):"-");
    chinese(0,36,valve_closed?"\xe9\x98\x80\xe5\x85\xb3" /* 阀关 */:"\xe9\x98\x80\xe5\xbc\x80" /* 阀开 */);chinese(32,36,fan?"\xe9\xa3\x8e\xe5\xbc\x80" /* 风开 */:"\xe9\xa3\x8e\xe5\x81\x9c" /* 风停 */);
    chinese(64,36,buzzer?"\xe9\xb8\xa3\xe5\xbc\x80" /* 鸣开 */:"\xe9\xb8\xa3\xe5\x81\x9c" /* 鸣停 */);chinese(96,36,relay?"\xe7\x94\xb5\xe5\xbc\x80" /* 电开 */:"\xe7\x94\xb5\xe5\x81\x9c" /* 电停 */);
    snprintf(text,sizeof(text),"#%lu",(unsigned long)sequence);ascii(0,48,text);
    snprintf(text,sizeof(text),"%02lu:%02lu:%02lu",(unsigned long)(uptime_ms/3600000u%100u),
             (unsigned long)(uptime_ms/60000u%60u),(unsigned long)(uptime_ms/1000u%60u));ascii(65,48,text);
    ascii(0,56,"REL EST UNCAL");
    ascii(67,56,!enabled?"IDLE":injection?"DRILL":"REAL");
    snprintf(text,sizeof(text),"%lu.%luHz",(unsigned long)(smooth_rate/10u),(unsigned long)(smooth_rate%10u));ascii(100,56,text);
    atk_oled_refresh_changed();
}
