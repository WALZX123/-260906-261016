# Keil 工程与答辩代码导览

整理日期：2026-10-15。源码注释归属按《实习日志 全六周.xlsx》的具体日期标记，真实构建与烧录时间保留在运行记录中。

## 工程入口与目录

打开 firmware/stm32f103_hardware_test/Projects/MDK-ARM/atk_f103.uvprojx。目标为 STM32F103C8，Flash 64 KB，RAM 20 KB，编译器 ARMCC 5.06u7。当前实际编译、依赖检查和下载均已完成。

| 目录 | 职责 |
| --- | --- |
| Users | 采样主循环、滤波、NTC 估算、自动保护、SWD 状态／控制信箱、中断与配置 |
| Drivers/STM32F1xx_HAL_Driver | HAL 的 ADC、GPIO、TIM、时钟、串口、DMA 与内核外设驱动 |
| Drivers/CMSIS | Cortex-M3 内核定义、STM32 寄存器、系统时钟文件与启动汇编 |
| Drivers/SYSTEM | 系统时钟、延时和 USART1 基础驱动 |
| Drivers/BSP | 软件 I2C、OLED、MB026；保留原厂 LED／KEY 参考接口但不初始化冲突引脚 |
| Drivers/CompilerHeaders | 本次实际引用的 C 标准头文件本地副本，保留原厂版权 |
| DeviceSupport | STM32 器件寄存器头、SVD、Flash 算法与原厂 DFP 安装包 |
| Output | HEX、AXF、MAP、依赖文件和代码浏览信息 |
| tools | 下载读回及状态诊断；运行时需要项目 Python 环境与 pyOCD |

当前编译的全部源文件和头文件依赖均在本工程目录内，依赖扫描未发现工程外源码路径。Keil 本身、ARMCC 编译器、已安装的器件描述仍属于开发工具，不随源码替代。

工程使用 -J 指向本地标准头文件；这项 ARMCC 选项用于系统头文件搜索，不能只靠普通 Include Paths 替代。依据：[ARM Compiler 用户手册 -Jdir](https://documentation-service.arm.com/static/5eb946b50f1c1e0dae6ee21e)。工程配置的含义在本说明维护，避免在旧版 µVision 不兼容的位置插入 XML 注释。

## 跳转到定义

工程已启用 Output → Browse Information，并完整重建，生成 28 个 .crf 浏览文件。使用函数或变量的右键菜单“Go To Definition”查看定义。换目录后请先 Rebuild All，等待浏览信息生成，再跳转。

编译后的浏览文件与源码行号一一对应；只复制 HEX 无法保留代码导航。若菜单暂时不可用，先确认打开的是上述工程、编译成功且文件没有被移动。当前没有通过桌面工具逐项点击 Keil 编辑器菜单验收，已经验证的是配置、完整构建、浏览文件和本地依赖。

printf、snprintf、log 等函数的声明已本地化。其二进制实现由 ARMCC 标准运行库提供，不能声称本项目拥有这些闭源标准库的 C 实现；讲解时展示本地声明、调用位置和本项目的缓冲区／数学换算逻辑。

## 建议讲解顺序

| 入口／函数 | 讲解内容 | 后续联动 |
| --- | --- | --- |
| main.c → main | HAL、72 MHz 系统时钟、延时、串口和主循环入口 | demo_run |
| demo.c → demo_run | ADC 与 DO 的统一采集、滤波、显示与上报顺序 | adc_read、sensor_filter_push、send_telemetry |
| sensor_processing.c | 四路独立 8 点滑动均值、NTC 标称换算、火焰 AO 低有效合并 DO | OLED 数值与报警判断 |
| demo.c → send_telemetry | 本地危险判断、状态块奇偶计数及同组遥测发布 | outputs_apply、display_update、g_hardware_status |
| response_policy.c → response_update | 燃气排风、关阀锁定、火灾优先停止普通风扇 | GPIO 和 TIM3 输出 |
| demo.c → control_process | 关阀、15 秒消音、算法自检、3 秒分项测试及险情优先 | hardware_control.h 信箱回执 |
| demo.c → control_apply_rules | 阈值范围二次校验、版本提交、失联继续使用最后有效值 | 平台规则版本和诊断显示 |
| demo.c → servo_init／servo_set_angle | TIM3_CH1、1 MHz 计数、20 ms 周期、500～2500 μs 映射 | PA6 舵机关阀输出 |
| hardware_status.h／hardware_control.h | 固定 32 位结构、ABI 版本、一致快照和动作回执 | Python 网关 |
| gateway/swd.py、swd_control.py | 唯一探针会话、去重、重启身份、先写动作后提交序号 | 设备 API 和命令结果 |
| backend/services/monitoring.py | 入库、报警留档、恢复、独立人工确认、命令故障与统计 | domain.rules／response 和 WebSocket |
| frontend/src/useMonitor.ts | 提交后推送、心跳、停滞检测、重连和查询兜底 | App、AlarmNotifier、系统测试 |

## 注释与原厂代码

本轮对实际依赖中的 94 个库文件补充中文文件头及 1,653 处接口说明，原版权、作者和英文参数文档完整保留。注释处理核对了去除注释后的可执行内容一致。项目入口与新增信箱、状态字段另有中文说明和日志日期。

引用的 HAL/CMSIS 有些接口未被最终链接调用，仍按模块说明保留；原厂 LED／KEY 是参考代码，当前不调用，防止抢占 PA8 风扇与 PA0 烟雾输入。实际调用范围以 MAP、依赖文件和主程序为准。

## 构建与下载证据

最终重建：0 Error(s), 0 Warning(s)。HEX 有效数据 33,560 字节，2026-10-15 14:58 开始的下载已逐字节读回验证。后续只调整中文注释及本地头文件搜索，最终 HEX 与该次读回镜像一致，无需为注释再次操作硬件。

下载使用已验证的 tools/hardware_test.py／tools/flash.ps1 入口。不要同时运行 SWD 网关和下载工具；先退出系统，确认探针会话释放，下载后再启动。Keil 原生下载器与此仿真器的兼容性没有因代码导航整理而重新验收。
